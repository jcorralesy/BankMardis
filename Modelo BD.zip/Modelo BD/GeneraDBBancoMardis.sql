
--SELECT * FROM dbo.Cuenta
--SELECT * FROM dbo.cliente
--SELECT * FROM dbo.persona
--SELECT * FROM dbo.transaccion

--DROP TABLE dbo.transaccion
--DROP TABLE dbo.Cuenta
--DROP TABLE dbo.cliente
--DROP TABLE dbo.persona

/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2008                    */
/* Created on:     24/4/2022 18:29:16                           */
/*==============================================================*/


IF EXISTS
(
    SELECT 1
    FROM sys.sysreferences r
        JOIN sys.sysobjects o
            ON (
                   o.id = r.constid
                   AND o.type = 'F'
               )
    WHERE r.fkeyid = OBJECT_ID('CLIENTE')
          AND o.name = 'FK_CLIENTE_RELATIONS_PERSONA'
)
    ALTER TABLE CLIENTE DROP CONSTRAINT FK_CLIENTE_RELATIONS_PERSONA;
GO

IF EXISTS
(
    SELECT 1
    FROM sys.sysreferences r
        JOIN sys.sysobjects o
            ON (
                   o.id = r.constid
                   AND o.type = 'F'
               )
    WHERE r.fkeyid = OBJECT_ID('CUENTA')
          AND o.name = 'FK_CUENTA_RELATIONS_CLIENTE'
)
    ALTER TABLE CUENTA DROP CONSTRAINT FK_CUENTA_RELATIONS_CLIENTE;
GO

IF EXISTS
(
    SELECT 1
    FROM sys.sysreferences r
        JOIN sys.sysobjects o
            ON (
                   o.id = r.constid
                   AND o.type = 'F'
               )
    WHERE r.fkeyid = OBJECT_ID('TRANSACCION')
          AND o.name = 'FK_TRANSACC_RELATIONS_CUENTA'
)
    ALTER TABLE TRANSACCION DROP CONSTRAINT FK_TRANSACC_RELATIONS_CUENTA;
GO

IF EXISTS
(
    SELECT 1
    FROM sysindexes
    WHERE id = OBJECT_ID('CLIENTE')
          AND name = 'RELATIONSHIP_1_FK'
          AND indid > 0
          AND indid < 255
)
    DROP INDEX CLIENTE.RELATIONSHIP_1_FK;
GO

IF EXISTS
(
    SELECT 1
    FROM sysobjects
    WHERE id = OBJECT_ID('CLIENTE')
          AND type = 'U'
)
    DROP TABLE CLIENTE;
GO

IF EXISTS
(
    SELECT 1
    FROM sysindexes
    WHERE id = OBJECT_ID('CUENTA')
          AND name = 'RELATIONSHIP_2_FK'
          AND indid > 0
          AND indid < 255
)
    DROP INDEX CUENTA.RELATIONSHIP_2_FK;
GO

IF EXISTS
(
    SELECT 1
    FROM sysobjects
    WHERE id = OBJECT_ID('CUENTA')
          AND type = 'U'
)
    DROP TABLE CUENTA;
GO

IF EXISTS
(
    SELECT 1
    FROM sysobjects
    WHERE id = OBJECT_ID('PERSONA')
          AND type = 'U'
)
    DROP TABLE PERSONA;
GO

IF EXISTS
(
    SELECT 1
    FROM sysindexes
    WHERE id = OBJECT_ID('TRANSACCION')
          AND name = 'RELATIONSHIP_3_FK'
          AND indid > 0
          AND indid < 255
)
    DROP INDEX TRANSACCION.RELATIONSHIP_3_FK;
GO

IF EXISTS
(
    SELECT 1
    FROM sysobjects
    WHERE id = OBJECT_ID('TRANSACCION')
          AND type = 'U'
)
    DROP TABLE TRANSACCION;
GO

/*==============================================================*/
/* Table: CLIENTE                                               */
/*==============================================================*/
CREATE TABLE CLIENTE
(
    ID INT
        UNIQUE NOT NULL,
    IDPERSONA INT NULL,
    CONTRASENA VARCHAR(10) NULL,
    ESTADO VARCHAR(1) NULL,
    CONSTRAINT PK_CLIENTE
        PRIMARY KEY NONCLUSTERED (ID)
);
GO

/*==============================================================*/
/* Index: RELATIONSHIP_1_FK                                     */
/*==============================================================*/
CREATE INDEX RELATIONSHIP_1_FK ON CLIENTE (IDPERSONA ASC);
GO

/*==============================================================*/
/* Table: CUENTA                                                */
/*==============================================================*/
CREATE TABLE CUENTA
(
    ID INT
        UNIQUE NOT NULL,
    IDCLIENTE INT NULL,
    NUMEROCUENTA VARCHAR(5) NULL,
    ESTADO VARCHAR(1) NULL,
    CONSTRAINT PK_CUENTA
        PRIMARY KEY NONCLUSTERED (ID)
);
GO

/*==============================================================*/
/* Index: RELATIONSHIP_2_FK                                     */
/*==============================================================*/
CREATE INDEX RELATIONSHIP_2_FK ON CUENTA (IDCLIENTE ASC);
GO

/*==============================================================*/
/* Table: PERSONA                                               */
/*==============================================================*/
CREATE TABLE PERSONA
(
    NOMBRE VARCHAR(100) NULL,
    APELLIDO VARCHAR(100) NULL,
    DOCUMENTO VARCHAR(13) NULL,
    FECHANACIMIENTO DATETIME NULL,
    GENERO VARCHAR(1) NULL,
    DIRECCION VARCHAR(500) NULL,
    TELEFONO VARCHAR(10) NULL,
    TIPOPERSONA VARCHAR(1) NULL,
    ID INT
        UNIQUE NOT NULL,
    CONSTRAINT PK_PERSONA
        PRIMARY KEY NONCLUSTERED (ID)
);
GO

/*==============================================================*/
/* Table: TRANSACCION                                           */
/*==============================================================*/
CREATE TABLE TRANSACCION
(
    ID INT
        UNIQUE NOT NULL,
    IDCUENTA INT NULL,
    FECHA DATETIME NULL,
    TIPOMOVIMIENTO VARCHAR(5) NULL,
    VALOR FLOAT NULL,
    SALDO FLOAT NULL,
    CONSTRAINT PK_TRANSACCION
        PRIMARY KEY NONCLUSTERED (ID)
);
GO

/*==============================================================*/
/* Index: RELATIONSHIP_3_FK                                     */
/*==============================================================*/
CREATE INDEX RELATIONSHIP_3_FK ON TRANSACCION (IDCUENTA ASC);
GO

ALTER TABLE CLIENTE
ADD CONSTRAINT FK_CLIENTE_RELATIONS_PERSONA
    FOREIGN KEY (IDPERSONA)
    REFERENCES PERSONA (ID);
GO

ALTER TABLE CUENTA
ADD CONSTRAINT FK_CUENTA_RELATIONS_CLIENTE
    FOREIGN KEY (IDCLIENTE)
    REFERENCES CLIENTE (ID);
GO

ALTER TABLE TRANSACCION
ADD CONSTRAINT FK_TRANSACC_RELATIONS_CUENTA
    FOREIGN KEY (IDCUENTA)
    REFERENCES CUENTA (ID);
GO

